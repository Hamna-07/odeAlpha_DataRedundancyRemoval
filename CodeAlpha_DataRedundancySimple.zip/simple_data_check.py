# File: simple_data_check.py

def load_data():
    try:
        with open("data.txt", "r") as f:
            return f.read().splitlines()
    except FileNotFoundError:
        return []

def save_data(email, name):
    with open("data.txt", "a") as f:
        f.write(f"{email},{name}\n")

def main():
    print("Simple Data Entry Program")
    name = input("Enter your name: ")
    email = input("Enter your email: ")

    existing_data = load_data()

    if any(email in line for line in existing_data):
        print("Duplicate entry found. Not saved.")
    else:
        save_data(email, name)
        print("Data saved successfully!")

if __name__ == "__main__":
    main()
