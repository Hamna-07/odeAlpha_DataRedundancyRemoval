# Simple Data Redundancy Remover

This is a beginner-level project that checks for duplicate email entries before saving them.

## Features
- Accepts name and email
- Checks if email already exists
- Saves only unique entries

## How it Works
- Stores data in a file called `data.txt`
- Prevents duplicate emails

## How to Run
1. Open terminal or command prompt.
2. Run the file using: `python simple_data_check.py`
3. Enter name and email.
